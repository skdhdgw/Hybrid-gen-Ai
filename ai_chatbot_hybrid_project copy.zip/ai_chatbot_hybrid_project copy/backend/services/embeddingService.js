const axios = require("axios");

let EMBEDDINGS_DISABLED = false; // auto-disable on 429

async function getEmbedding(text) {
  if (EMBEDDINGS_DISABLED) return null;

  const provider = (process.env.PROVIDER || "openai").toLowerCase();

  try {
    // ✅ GEMINI EMBEDDINGS (Preferred: higher limits)
    if (provider === "gemini") {
      if (!process.env.GEMINI_API_KEY) return null;

      const url =
        `https://generativelanguage.googleapis.com/v1beta/models/text-embedding-004:embedText?key=${process.env.GEMINI_API_KEY}`;

      const resp = await axios.post(url, { text });
      return resp.data.embedding?.value || [];
    }

    // ✅ OPENAI EMBEDDINGS
    if (!process.env.OPENAI_API_KEY) return null;

    const resp = await axios.post(
      "https://api.openai.com/v1/embeddings",
      {
        model: "text-embedding-3-small",
        input: text
      },
      {
        headers: {
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );

    return resp.data.data[0].embedding;

  } catch (err) {
    // ✅ Disable embeddings permanently after rate limit
    if (err.response?.status === 429) {
      EMBEDDINGS_DISABLED = true;
      console.warn("⚠️ Embeddings disabled due to rate limit (429)");
      return null;
    }

    console.warn("⚠️ Embedding error:", err.message);
    return null;
  }
}

function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;

  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  return na && nb ? dot / (Math.sqrt(na) * Math.sqrt(nb)) : 0;
}

module.exports = { getEmbedding, cosineSimilarity };
