const axios = require("axios");

async function callLLM(message) {
  const provider = (process.env.PROVIDER || "openai").toLowerCase();

  /* ===================== GEMINI ===================== */
  if (provider === "gemini") {
    const API_KEY = process.env.GEMINI_API_KEY;
    if (!API_KEY) throw new Error("GEMINI_API_KEY not set");

    const url =
      "https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=" +
      API_KEY;

    try {
      const resp = await axios.post(url, {
        contents: [
          {
            role: "user",
            parts: [{ text: message }]
          }
        ]
      });

      return (
        resp.data?.candidates?.[0]?.content?.parts?.[0]?.text ||
        "No response from Gemini"
      );
    } catch (err) {
      console.error("Gemini error:", err.response?.data || err.message);
      throw err;
    }
  }

  /* ===================== OPENAI ===================== */
  if (provider === "openai") {
    const API_KEY = process.env.OPENAI_API_KEY;
    if (!API_KEY) throw new Error("OPENAI_API_KEY not set");

    const resp = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: message }]
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${API_KEY}`
        }
      }
    );

    return resp.data.choices[0].message.content.trim();
  }

  throw new Error(`Unknown PROVIDER: ${provider}`);
}

module.exports = { callLLM };
