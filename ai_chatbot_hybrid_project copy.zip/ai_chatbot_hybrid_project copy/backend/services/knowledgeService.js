
const fs = require("fs");
const path = require("path");
const { getEmbedding, cosineSimilarity } = require("./embeddingService");

const DB_PATH = path.join(__dirname, "..", "knowledge.json");

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ items: [], nextId: 1 }, null, 2));
  }
  const raw = fs.readFileSync(DB_PATH, "utf8");
  return JSON.parse(raw);
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function listKnowledge() {
  const db = loadDB();
  return db.items;
}

async function addKnowledge(question, answer) {
  const db = loadDB();
  const emb = await getEmbedding(question);
  const item = {
    id: db.nextId || 1,
    question,
    answer,
    embedding: emb
  };
  db.items.push(item);
  db.nextId = (db.nextId || 1) + 1;
  saveDB(db);
  return item;
}

function deleteKnowledge(id) {
  const db = loadDB();
  const lenBefore = db.items.length;
  db.items = db.items.filter(i => i.id !== id);
  const changed = db.items.length !== lenBefore;
  if (changed) saveDB(db);
  return changed;
}

function bestMatchByEmbedding(queryEmbedding, db, threshold = 0.82) {
  let best = null;
  let bestScore = 0;
  for (const item of db.items) {
    if (!item.embedding || !item.embedding.length) continue;
    const score = cosineSimilarity(queryEmbedding, item.embedding);
    if (score > bestScore) {
      bestScore = score;
      best = item;
    }
  }
  if (best && bestScore >= threshold) {
    return { item: best, score: bestScore };
  }
  return null;
}

module.exports = { loadDB, saveDB, listKnowledge, addKnowledge, deleteKnowledge, bestMatchByEmbedding };
