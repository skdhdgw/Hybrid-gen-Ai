
const { loadDB, saveDB, bestMatchByEmbedding } = require("./knowledgeService");
const { getEmbedding } = require("./embeddingService");
const { callLLM } = require("./llmService");

async function chatHandler(message) {
  const db = loadDB();

  // 1) Try semantic match using embeddings
  let queryEmb = null;
  try {
    queryEmb = await getEmbedding(message);
  } catch (e) {
    console.warn("Embedding error, falling back to simple search:", e.message);
  }

  if (queryEmb) {
    const match = bestMatchByEmbedding(queryEmb, db);
    if (match) {
      return {
        answer: match.item.answer,
        source: "local-embedding",
        score: match.score,
        id: match.item.id
      };
    }
  }

  // 2) Simple exact match (fallback)
  const lower = message.toLowerCase().trim();
  const simple = db.items.find(
    i => i.question.toLowerCase().trim() === lower
  );
  if (simple) {
    return {
      answer: simple.answer,
      source: "local-exact",
      id: simple.id
    };
  }

  // 3) Call external LLM (OpenAI or Gemini)
  const aiAnswer = await callLLM(message);

  // 4) Save new Q&A + embedding into local JSON DB
  let newEmb = [];
  try {
    newEmb = await getEmbedding(message);
  } catch (e) {
    console.warn("Unable to embed new question:", e.message);
  }

  const nextId = db.nextId || (db.items.length ? Math.max(...db.items.map(i => i.id)) + 1 : 1);
  const item = {
    id: nextId,
    question: message,
    answer: aiAnswer,
    embedding: newEmb
  };
  db.items.push(item);
  db.nextId = nextId + 1;
  saveDB(db);

  return {
    answer: aiAnswer,
    source: "llm",
    id: item.id
  };
}

module.exports = { chatHandler };
