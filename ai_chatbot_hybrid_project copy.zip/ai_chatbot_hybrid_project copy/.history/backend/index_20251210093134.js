const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const path = require("path");

const {
  chatHandler
} = require("./services/chatService");

const {
  listKnowledge,
  addKnowledge,
  deleteKnowledge
} = require("./services/knowledgeService");

// Load .env variables
dotenv.config();

const app = express();

// ---------- MIDDLEWARE ----------
app.use(cors());
app.use(express.json());

// ---------- CHAT API ----------
app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({ error: "message is required" });
    }

    const reply = await chatHandler(message);
    return res.json(reply);

  } catch (err) {
    console.error("Chat error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// ---------- KNOWLEDGE BASE APIs ----------
app.get("/api/knowledge", (req, res) => {
  try {
    const data = listKnowledge();
    return res.json(data);
  } catch (err) {
    console.error("List knowledge error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/api/knowledge", async (req, res) => {
  try {
    const { question, answer } = req.body;

    if (!question || !answer) {
      return res
        .status(400)
        .json({ error: "question and answer are required" });
    }

    const item = await addKnowledge(question, answer);
    return res.json(item);

  } catch (err) {
    console.error("Add knowledge error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

app.delete("/api/knowledge/:id", (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const deleted = deleteKnowledge(id);

    if (!deleted) {
      return res.status(404).json({ error: "Item not found" });
    }

    return res.json({ success: true });

  } catch (err) {
    console.error("Delete knowledge error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// ---------- SERVE FRONTEND ----------
app.use(express.static(path.join(__dirname, "..", "frontend")));

// ---------- START SERVER (AUTO PORT FIX ✅) ----------
const PORT = process.env.PORT || 0; // 0 = auto-select free port

const server = app.listen(PORT, () => {
  const actualPort = server.address().port;
  console.log(`✅ Server running on http://localhost:${actualPort}`);
});
