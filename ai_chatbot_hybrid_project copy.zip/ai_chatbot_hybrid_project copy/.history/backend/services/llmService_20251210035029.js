
const axios = require("axios");

async function callLLM(message) {
  const provider = (process.env.PROVIDER || "openai").toLowerCase();

  if (provider === "gemini") {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error("GEMINI_API_KEY not set");
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`;
    const resp = await axios.post(url, {
      contents: [{ parts: [{ text: message }] }]
    });
    const text = resp.data.candidates?.[0]?.content?.parts?.[0]?.text || "No answer from Gemini.";
    return text;
  }

  // Default to OpenAI chat
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY not set");
  }
  const resp = await axios.post(
    "https://api.openai.com/v1/chat/completions",
    {
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: message }]
    },
    {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      }
    }
  );
  return resp.data.choices[0].message.content.trim();
}

module.exports = { callLLM };
