
const axios = require("axios");

async function getEmbedding(text) {
  const provider = (process.env.PROVIDER || "openai").toLowerCase();

  if (provider === "gemini") {
    if (!process.env.GEMINI_API_KEY) throw new Error("GEMINI_API_KEY not set");
    // Gemini text embedding API (v1beta)
    const url = `https://generativelanguage.googleapis.com/v1beta/models/text-embedding-004:embedText?key=${process.env.GEMINI_API_KEY}`;
    const resp = await axios.post(url, { text });
    const vector = resp.data.embedding?.value || resp.data.embedding?.values || [];
    return vector;
  }

  // Default to OpenAI
  if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY not set");
  const resp = await axios.post(
    "https://api.openai.com/v1/embeddings",
    {
      model: "text-embedding-3-small",
      input: text
    },
    {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      }
    }
  );
  return resp.data.data[0].embedding;
}

function cosineSimilarity(a, b) {
  if (!a || !b || a.length === 0 || b.length === 0 || a.length !== b.length) return 0;
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (!na || !nb) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

module.exports = { getEmbedding, cosineSimilarity };
