
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const path = require("path");
const bodyParser = require("body-parser");

const { chatHandler } = require("./services/chatService");
const { listKnowledge, addKnowledge, deleteKnowledge } = require("./services/knowledgeService");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.json());

// Chat endpoint (main chatbot)
app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "message is required" });

    const reply = await chatHandler(message);
    return res.json(reply);
  } catch (err) {
    console.error("chat error", err);
    res.status(500).json({ error: "server error" });
  }
});

// Knowledge base admin endpoints
app.get("/api/knowledge", (req, res) => {
  return res.json(listKnowledge());
});

app.post("/api/knowledge", async (req, res) => {
  try {
    const { question, answer } = req.body;
    if (!question || !answer) {
      return res.status(400).json({ error: "question and answer required" });
    }
    const item = await addKnowledge(question, answer);
    return res.json(item);
  } catch (err) {
    console.error("add knowledge error", err);
    res.status(500).json({ error: "server error" });
  }
});

app.delete("/api/knowledge/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const ok = deleteKnowledge(id);
  if (!ok) return res.status(404).json({ error: "not found" });
  return res.json({ success: true });
});

// Serve frontend
app.use(express.static(path.join(__dirname, "..", "frontend")));

const PORT = process.env.PORT || 0;
app.listen(PORT, () => {
  console.log("Server running on http://localhost:" +  server.address().port);
});
